THE COMMONS — LM STUDIO MCP PACKAGE

Files:
  mcp.json
  commons_mcp_server.js
  .commons/state.json
  .commons/history.jsonl

INSTALL:
1. Put the entire folder somewhere permanent.
2. Make sure Deno is installed and available as `deno` on PATH.
3. In LM Studio, install/load the MCP configuration from mcp.json.
4. If LM Studio cannot find `deno`, replace the command in mcp.json with the full path to deno.exe.

The server uses MCP stdio JSON-RPC. stdout is reserved for MCP protocol traffic; diagnostics go to stderr.

The Commons data directory is resolved relative to commons_mcp_server.js, not LM Studio's current working directory.

IMPORTANT:
This is a runnable MCP integration layer implementing the concrete V1 tool surface recovered from the prior Commons build record. The larger Commons specification contains additional architectural requirements that are not represented by the original small bootstrap tool set; those should not be falsely described as fully implemented merely because this server launches.
