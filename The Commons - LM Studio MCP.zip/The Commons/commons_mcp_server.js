// The Commons — LM Studio MCP server
// Deno / stdio MCP transport. No external dependencies.

const ROOT = new URL('.', import.meta.url);
const COMMONS = new URL('.commons/', ROOT);
const STATE_FILE = new URL('state.json', COMMONS);
const HISTORY_FILE = new URL('history.jsonl', COMMONS);
const SERVER_VERSION = '1.0.0';
const PROTOCOL_VERSION = '2025-06-18';

const encoder = new TextEncoder();

function now() { return new Date().toISOString(); }
function id(prefix) {
  return `${prefix}-${crypto.randomUUID()}`;
}

function assertSafeRelativePath(path) {
  if (typeof path !== 'string' || !path.trim()) throw new Error('path is required');
  const p = path.replaceAll('\\', '/');
  if (p.startsWith('/') || /^[A-Za-z]:\//.test(p) || p.startsWith('//')) {
    throw new Error('absolute paths are not allowed');
  }
  const parts = p.split('/');
  if (parts.some(x => x === '..')) throw new Error('path traversal is not allowed');
  if (p === '.' || p.endsWith('/')) throw new Error('path must identify a file');
  return p;
}

function fileUrl(path) {
  return new URL(assertSafeRelativePath(path), ROOT);
}

async function ensureStore() {
  await Deno.mkdir(COMMONS, { recursive: true });
  try { await Deno.stat(STATE_FILE); }
  catch {
    const state = {
      schema: 'the-commons.state.v1',
      version: 1,
      created_at: now(),
      updated_at: now(),
      participants: {},
      roles: {},
      tables: {},
      domains: {},
      state: {},
      snapshots: {},
      branches: {},
      permissions: {},
      grants: {},
      indexes: {},
      policies: {},
      transfers: {},
      acknowledgements: {},
      audits: [],
      context: { current_table_id: null }
    };
    await Deno.writeTextFile(STATE_FILE, JSON.stringify(state, null, 2) + '\n');
  }
  try { await Deno.stat(HISTORY_FILE); }
  catch { await Deno.writeTextFile(HISTORY_FILE, ''); }
}

async function readState() {
  await ensureStore();
  return JSON.parse(await Deno.readTextFile(STATE_FILE));
}

async function writeState(state, operation, details = {}) {
  state.updated_at = now();
  state.version = Number(state.version || 0) + 1;
  const record = {
    event_id: id('evt'),
    timestamp: now(),
    version: state.version,
    operation,
    details
  };
  state.audits ??= [];
  state.audits.push(record);
  await Deno.writeTextFile(STATE_FILE, JSON.stringify(state, null, 2) + '\n');
  await Deno.writeTextFile(HISTORY_FILE, JSON.stringify({
    ...record,
    state_hash: await sha256(JSON.stringify(state))
  }) + '\n', { append: true });
  return record;
}

async function sha256(text) {
  const digest = await crypto.subtle.digest('SHA-256', encoder.encode(text));
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, '0')).join('');
}

function textResult(value, isError = false) {
  return {
    content: [{ type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) }],
    isError
  };
}

const tools = [
  { name: 'initialize', description: 'Initialize or verify the Commons persistent store.', inputSchema: { type: 'object', properties: {} } },
  { name: 'status', description: 'Return Commons status and object counts.', inputSchema: { type: 'object', properties: {} } },
  { name: 'list_files', description: 'List files beneath the Commons server directory.', inputSchema: { type: 'object', properties: { path: { type: 'string', description: 'Relative directory, default .' } } } },
  { name: 'read_file', description: 'Read a text file inside the Commons directory.', inputSchema: { type: 'object', required: ['path'], properties: { path: { type: 'string' } } } },
  { name: 'file_exists', description: 'Check whether a relative file exists.', inputSchema: { type: 'object', required: ['path'], properties: { path: { type: 'string' } } } },
  { name: 'create_file', description: 'Create a new text file; fails if it already exists.', inputSchema: { type: 'object', required: ['path'], properties: { path: { type: 'string' }, content: { type: 'string' } } } },
  { name: 'write_file', description: 'Write/replace a text file.', inputSchema: { type: 'object', required: ['path'], properties: { path: { type: 'string' }, content: { type: 'string' } } } },
  { name: 'delete_file', description: 'Delete a file inside the Commons directory.', inputSchema: { type: 'object', required: ['path'], properties: { path: { type: 'string' } } } },
  { name: 'register_participant', description: 'Register a human, AI, or other Commons participant.', inputSchema: { type: 'object', required: ['name','type'], properties: { name: { type: 'string' }, type: { type: 'string' }, capabilities: { type: 'array', items: { type: 'string' } }, permissions: { type: 'array', items: { type: 'string' } }, metadata: { type: 'object' } } } },
  { name: 'create_table', description: 'Create an isolated contextual table.', inputSchema: { type: 'object', required: ['name'], properties: { name: { type: 'string' }, aliases: { type: 'array', items: { type: 'string' } }, type: { type: 'string' }, purpose: { type: 'string' }, parent_table_id: { type: 'string' }, creator_id: { type: 'string' }, inheritance: { type: 'string', enum: ['ISOLATED','INHERIT','INHERIT_OVERRIDE','SHARED_EXPLICIT'] } } } },
  { name: 'register_vi', description: 'Register an AI/local virtual intelligence adapter.', inputSchema: { type: 'object', required: ['name'], properties: { name: { type: 'string' }, provider: { type: 'string' }, model: { type: 'string' }, capabilities: { type: 'array', items: { type: 'string' } }, metadata: { type: 'object' } } } },
  { name: 'history', description: 'Return append-only Commons operation history.', inputSchema: { type: 'object', properties: { limit: { type: 'integer', minimum: 1, maximum: 1000 } } } }
];

async function handleTool(name, args = {}) {
  await ensureStore();
  if (name === 'initialize') return { initialized: true, server: 'The Commons', version: SERVER_VERSION, root: ROOT.pathname };
  if (name === 'status') {
    const s = await readState();
    const counts = Object.fromEntries(['participants','roles','tables','domains','state','snapshots','branches','permissions','grants','indexes','policies','transfers','acknowledgements'].map(k => [k, Object.keys(s[k] ?? {}).length]));
    return { server: 'The Commons', version: SERVER_VERSION, schema: s.schema, version_number: s.version, updated_at: s.updated_at, context: s.context, counts };
  }
  if (name === 'list_files') {
    const rel = typeof args.path === 'string' && args.path !== '' ? args.path : '.';
    if (rel !== '.') assertSafeRelativePath(rel);
    const base = rel === '.' ? ROOT : fileUrl(rel + '/');
    const out = [];
    for await (const e of Deno.readDir(base)) out.push({ name: e.name, type: e.isDirectory ? 'directory' : 'file' });
    return out;
  }
  if (name === 'read_file') return await Deno.readTextFile(fileUrl(args.path));
  if (name === 'file_exists') {
    try { await Deno.stat(fileUrl(args.path)); return { exists: true }; }
    catch (e) { if (e instanceof Deno.errors.NotFound) return { exists: false }; throw e; }
  }
  if (name === 'create_file') {
    const u = fileUrl(args.path); await Deno.mkdir(new URL('.', u), { recursive: true });
    await Deno.writeTextFile(u, args.content ?? '', { create: true, createNew: true });
    return { created: true, path: args.path };
  }
  if (name === 'write_file') {
    const u = fileUrl(args.path); await Deno.mkdir(new URL('.', u), { recursive: true });
    await Deno.writeTextFile(u, args.content ?? '');
    return { written: true, path: args.path };
  }
  if (name === 'delete_file') { await Deno.remove(fileUrl(args.path)); return { deleted: true, path: args.path }; }
  if (name === 'register_participant') {
    if (!args.name || !args.type) throw new Error('name and type are required');
    const s = await readState(); const participant_id = id('participant');
    s.participants[participant_id] = { participant_id, name: args.name, type: args.type, capabilities: args.capabilities ?? [], permissions: args.permissions ?? [], metadata: args.metadata ?? {}, created_at: now() };
    await writeState(s, 'REGISTER_PARTICIPANT', { participant_id });
    return s.participants[participant_id];
  }
  if (name === 'create_table') {
    if (!args.name) throw new Error('name is required');
    const s = await readState(); const table_id = id('table');
    const inheritance = args.inheritance ?? 'ISOLATED';
    if (!['ISOLATED','INHERIT','INHERIT_OVERRIDE','SHARED_EXPLICIT'].includes(inheritance)) throw new Error('invalid inheritance mode');
    s.tables[table_id] = { table_id, name: args.name, aliases: args.aliases ?? [], parent_table_id: args.parent_table_id ?? null, lineage: args.parent_table_id ? [args.parent_table_id, table_id] : [table_id], type: args.type ?? 'TABLE', configuration: {}, purpose: args.purpose ?? '', creator: args.creator_id ?? null, participants: [], permissions: [], local_agent: null, keyword_directory: {}, history: [], content_policy: {}, eligibility_policy: {}, domain_attachment: null, inheritance, created_at: now() };
    await writeState(s, 'CREATE_TABLE', { table_id });
    return s.tables[table_id];
  }
  if (name === 'register_vi') {
    if (!args.name) throw new Error('name is required');
    const s = await readState(); const vi_id = id('vi');
    s.domains ??= {}; s.domains[vi_id] = { vi_id, name: args.name, provider: args.provider ?? null, model: args.model ?? null, capabilities: args.capabilities ?? [], metadata: args.metadata ?? {}, registered_at: now() };
    await writeState(s, 'REGISTER_VI', { vi_id });
    return s.domains[vi_id];
  }
  if (name === 'history') {
    const limit = Math.min(Math.max(Number(args.limit ?? 100), 1), 1000);
    const raw = await Deno.readTextFile(HISTORY_FILE);
    const lines = raw.split('\n').filter(Boolean).slice(-limit);
    return lines.map(x => JSON.parse(x));
  }
  throw new Error(`Unknown tool: ${name}`);
}

async function reply(message, result, error = null) {
  const out = { jsonrpc: '2.0', id: message.id };
  if (error) out.error = { code: error.code ?? -32603, message: error.message ?? String(error) };
  else out.result = result;
  await Deno.stdout.write(encoder.encode(JSON.stringify(out) + '\n'));
}

async function dispatch(message) {
  const method = message.method;
  if (method === 'initialize') {
    return reply(message, {
      protocolVersion: message.params?.protocolVersion ?? PROTOCOL_VERSION,
      capabilities: { tools: {} },
      serverInfo: { name: 'the-commons', version: SERVER_VERSION },
      instructions: 'The Commons is a domain-neutral persistent environment. Use its tools as the controlled interface to Commons state.'
    });
  }
  if (method === 'notifications/initialized' || method === 'notifications/cancelled') return;
  if (method === 'ping') return reply(message, {});
  if (method === 'tools/list') return reply(message, { tools });
  if (method === 'tools/call') {
    try {
      const result = await handleTool(message.params?.name, message.params?.arguments ?? {});
      return reply(message, textResult(result));
    } catch (e) { return reply(message, textResult(e?.message ?? String(e), true)); }
  }
  if (message.id !== undefined) return reply(message, null, { code: -32601, message: `Method not found: ${method}` });
}

await ensureStore();
const decoder = new TextDecoder();
let buffer = '';
for await (const chunk of Deno.stdin.readable) {
  buffer += decoder.decode(chunk, { stream: true });
  let nl;
  while ((nl = buffer.indexOf('\n')) !== -1) {
    const line = buffer.slice(0, nl).trim(); buffer = buffer.slice(nl + 1);
    if (!line) continue;
    try { await dispatch(JSON.parse(line)); }
    catch (e) { console.error('Commons MCP error:', e); }
  }
}
