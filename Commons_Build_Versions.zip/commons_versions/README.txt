THE COMMONS — VERSION SET

Built from the Commons Architecture — Deep Dive / Extended blueprint.

Files:
  Commons_Blueprint_Source_of_Truth.txt  — architecture/specification reference
  Commons_JavaScript.js                  — JavaScript reference kernel
  Commons_CPP17.cpp                      — modern C++ reference implementation
  Commons_DOS_486.cpp                    — deliberately simple 486/DOS implementation

The DOS version is intentionally simple rather than a modern-C++ translation wearing a DOS label.
It preserves the Commons kernel concepts while using fixed records and period-style C++ constructs.

Important: the DOS source has not been executed on an actual 486 in this environment.
