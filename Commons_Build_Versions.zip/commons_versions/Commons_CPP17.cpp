/* THE COMMONS — C++17 reference implementation
   Source of truth: Commons Architecture — Deep Dive / Extended blueprint. */
#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include <string>
#include <ctime>
using namespace std;
static long stamp(){return (long)time(0);}
struct Provenance{string createdBy;long timestamp;string tableId;string operationId;};
struct Record{string id,data,classification,novelty;Provenance provenance;int importance=0,relevance=0,confidence=0;};
struct Table{string id,name,schema,parentId,domain,domainVersion;bool locked=false;vector<Record> records;};
struct Participant{string id,name,type,role;bool active=true;};
struct Role{string id,name,capabilities,permissions;};
struct Grant{string id,participantId,sourceTable,destinationTable,operation,scope,grantingAuthority,state;};
struct Version{string id,operationId,actor,reason;long timestamp;};
struct Audit{string id,operation,actor,tableId,versionId;long timestamp;};
struct Context{string id,tableId,actorId,task;vector<string> recordIds;};
struct Rule{string name,text;bool enabled=true;};
class CommonsCore{
public:
 int version=1; map<string,Table> tables; map<string,Participant> participants; map<string,Role> roles;
 vector<Grant> grants;vector<Version> history;vector<Audit> audit;vector<Context> contexts;vector<Rule> rules;
 CommonsCore(){installRules();}
 void installRules(){rules.push_back({"AI Output Is Not Authority","AI output is not automatically authoritative."});rules.push_back({"Provenance Required","Authoritative records require system-established provenance."});rules.push_back({"Identity Is Not Authorization","Identity does not grant permission."});rules.push_back({"Context Is Not Durable Memory","Working context is not the authoritative store."});rules.push_back({"Uncertainty Is Not Permission","UNVERIFIED and UNRESOLVED do not become permission."});rules.push_back({"Mutations Are Auditable","State changes create history and audit records."});}
 string makeId(const string&p,size_t n){return p+"-"+to_string(n+1);}
 string addParticipant(const string&name,const string&type){string i=makeId("P",participants.size());participants[i]={i,name,type,"",true};return i;}
 string addRole(const string&name){string i=makeId("ROLE",roles.size());roles[i]={i,name,"",""};return i;}
 string createTable(const string&name){string i=makeId("TABLE",tables.size());Table t;t.id=i;t.name=name;tables[i]=t;return i;}
 bool grant(const string&p,const string&t,const string&op,const string&a){Grant g;g.id=makeId("GRANT",grants.size());g.participantId=p;g.destinationTable=t;g.operation=op;g.grantingAuthority=a;g.state="AUTHORIZED";g.scope="TABLE";grants.push_back(g);return true;}
 bool authorized(const string&p,const string&op,const string&t){for(auto&g:grants)if(g.participantId==p&&g.operation==op&&g.destinationTable==t&&g.state=="AUTHORIZED")return true;return false;}
 bool append(const string&actor,const string&table,const string&data,const string&classification,bool explicitAuth){auto p=participants.find(actor),t=tables.find(table);if(p==participants.end()||t==tables.end()||t->second.locked)return false;if(p->second.type=="AI"&&!explicitAuth)return false;Record r;r.id=makeId("REC",t->second.records.size());r.data=data;r.classification=classification;r.novelty="New";r.provenance.createdBy=actor;r.provenance.timestamp=stamp();r.provenance.tableId=table;r.provenance.operationId=makeId("OP",history.size());t->second.records.push_back(r);Version v;v.id=makeId("VER",history.size());v.operationId=r.provenance.operationId;v.actor=actor;v.reason="APPEND";v.timestamp=stamp();history.push_back(v);Audit a;a.id=makeId("AUD",audit.size());a.operation="APPEND";a.actor=actor;a.tableId=table;a.versionId=v.id;a.timestamp=stamp();audit.push_back(a);++version;return true;}
 bool save(const string&file="commons_state.txt"){ofstream f(file);if(!f)return false;f<<version<<"\n";for(auto&r:rules)if(r.enabled)f<<"RULE|"<<r.name<<"|"<<r.text<<"\n";for(auto&t:tables){f<<"TABLE|"<<t.second.id<<"|"<<t.second.name<<"\n";for(auto&r:t.second.records)f<<"RECORD|"<<r.id<<"|"<<r.provenance.createdBy<<"|"<<r.data<<"\n";}return true;}
 void status(){cout<<"THE COMMONS "<<version<<"\nTables: "<<tables.size()<<"\nParticipants: "<<participants.size()<<"\nHistory: "<<history.size()<<"\nAudit: "<<audit.size()<<"\n";}
};
class ElderCouncil{public:struct Member{string id,name,perspective;};vector<Member>members;void addMember(const string&n,const string&p){members.push_back({"ELDER-"+to_string(members.size()+1),n,p});}};
class ThinkTank{public:struct Analyst{string id,name,perspective;};vector<Analyst>analysts;void addAnalyst(const string&n,const string&p){analysts.push_back({"AN-"+to_string(analysts.size()+1),n,p});}};
int main(){CommonsCore c;ElderCouncil e;ThinkTank t;e.addMember("Archivist","evidence and provenance");e.addMember("Steward","governance and continuity");e.addMember("Skeptic","challenge and uncertainty");e.addMember("Pragmatist","implementation and consequences");t.addAnalyst("Architect","system structure");t.addAnalyst("Engineer","implementation");t.addAnalyst("Researcher","evidence");t.addAnalyst("Devils Advocate","failure modes");t.addAnalyst("Pragmatist","operational usefulness");cout<<"THE COMMONS\nAI brings the intelligence; the Commons provides the table.\n";c.status();c.save();return 0;}
