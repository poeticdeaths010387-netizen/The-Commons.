/*
 THE COMMONS — SIMPLE 486 / DOS IMPLEMENTATION

 Source of truth: Commons Architecture — Deep Dive / Extended blueprint.
 Target style: 486-era DOS C++ (Turbo/Borland-style subset).

 Deliberate design:
 - fixed arrays
 - simple structs
 - no STL
 - no templates
 - no exceptions
 - no networking
 - no modern runtime
 - one small persistent state file

 The Commons core remains independent of the AI transport. A 486 DOS machine
 does not run modern LM Studio; the model/AI boundary therefore remains an
 interface boundary rather than being faked inside this program.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define MAX_TABLES 32
#define MAX_RECORDS 256
#define MAX_PARTICIPANTS 64
#define MAX_ROLES 32
#define MAX_GRANTS 128
#define MAX_HISTORY 256
#define MAX_AUDIT 512
#define MAX_RULES 32
#define MAX_CONTEXT 32
#define MAX_COUNCIL 16
#define MAX_ANALYSTS 16
#define MAX_TEXT 160
#define STATE_FILE "COMMONS.DAT"

struct PROVENANCE {
    char created_by[40];
    long timestamp;
    char table_id[32];
    char operation_id[32];
};

struct RECORD {
    char id[32];
    char data[MAX_TEXT];
    PROVENANCE provenance;
    char classification[16];
    char novelty[16];
    int importance;
    int relevance;
    int confidence;
};

struct TABLE {
    char id[32];
    char name[40];
    char schema[40];
    char parent_id[32];
    char domain[40];
    char domain_version[20];
    int locked;
    int record_count;
    RECORD records[MAX_RECORDS];
};

struct PARTICIPANT {
    char id[32];
    char name[40];
    char type[12];
    char role[32];
    int active;
};

struct ROLE {
    char id[32];
    char name[40];
    char capabilities[MAX_TEXT];
    char permissions[MAX_TEXT];
};

struct GRANT_RECORD {
    char id[32];
    char participant_id[32];
    char source_table[32];
    char destination_table[32];
    char operation[24];
    char scope[80];
    char granting_authority[40];
    char state[16];
};

struct VERSION_RECORD {
    char id[32];
    char operation_id[32];
    char actor[32];
    char reason[40];
    long timestamp;
};

struct AUDIT_RECORD {
    char id[32];
    char operation[24];
    char actor[32];
    char table_id[32];
    char version_id[32];
    long timestamp;
};

struct RULE {
    char name[80];
    char text[160];
    int enabled;
};

struct CONTEXT {
    char id[32];
    char table_id[32];
    char actor_id[32];
    char task[MAX_TEXT];
    int record_count;
    char record_ids[64][32];
};

struct ELDER {
    char id[32];
    char name[40];
    char perspective[80];
};

struct COUNCIL_SESSION {
    char id[32];
    char question[MAX_TEXT];
    int response_count;
    char responses[MAX_COUNCIL][MAX_TEXT];
};

struct ANALYST {
    char id[32];
    char name[40];
    char perspective[80];
};

struct THINK_SESSION {
    char id[32];
    char question[MAX_TEXT];
    int contribution_count;
    int challenge_count;
    char contributions[MAX_ANALYSTS][MAX_TEXT];
    char challenges[MAX_ANALYSTS][MAX_TEXT];
};

struct COMMONS_STATE {
    int version;
    int table_count;
    int participant_count;
    int role_count;
    int grant_count;
    int history_count;
    int audit_count;
    int rule_count;
    int context_count;
    TABLE tables[MAX_TABLES];
    PARTICIPANT participants[MAX_PARTICIPANTS];
    ROLE roles[MAX_ROLES];
    GRANT_RECORD grants[MAX_GRANTS];
    VERSION_RECORD history[MAX_HISTORY];
    AUDIT_RECORD audit[MAX_AUDIT];
    RULE rules[MAX_RULES];
    CONTEXT contexts[MAX_CONTEXT];
};

COMMONS_STATE C;
ELDER CouncilMembers[MAX_COUNCIL];
int CouncilMemberCount=0;
COUNCIL_SESSION CouncilSessions[MAX_COUNCIL];
int CouncilSessionCount=0;
ANALYST Analysts[MAX_ANALYSTS];
int AnalystCount=0;
THINK_SESSION ThinkSessions[MAX_ANALYSTS];
int ThinkSessionCount=0;

long stamp(void) { return (long)time(NULL); }

void copy_text(char *to, const char *from, int n)
{
    strncpy(to, from, n-1);
    to[n-1]=0;
}

void init_rules(void)
{
    C.rule_count=6;
    copy_text(C.rules[0].name,"AI Output Is Not Authority",80);
    copy_text(C.rules[0].text,"AI output is not automatically authoritative.",160);
    copy_text(C.rules[1].name,"Provenance Required",80);
    copy_text(C.rules[1].text,"Authoritative records require system-established provenance.",160);
    copy_text(C.rules[2].name,"Identity Is Not Authorization",80);
    copy_text(C.rules[2].text,"Identity does not grant permission.",160);
    copy_text(C.rules[3].name,"Context Is Not Durable Memory",80);
    copy_text(C.rules[3].text,"Working context is not the authoritative store.",160);
    copy_text(C.rules[4].name,"Uncertainty Is Not Permission",80);
    copy_text(C.rules[4].text,"UNVERIFIED and UNRESOLVED do not become permission.",160);
    copy_text(C.rules[5].name,"Mutations Are Auditable",80);
    copy_text(C.rules[5].text,"State changes create history and audit records.",160);
    C.rules[0].enabled=C.rules[1].enabled=C.rules[2].enabled=1;
    C.rules[3].enabled=C.rules[4].enabled=C.rules[5].enabled=1;
}

void init_commons(void)
{
    memset(&C,0,sizeof(C));
    C.version=1;
    init_rules();
}

int find_table(const char *id)
{
    int i;
    for(i=0;i<C.table_count;i++)
        if(strcmp(C.tables[i].id,id)==0) return i;
    return -1;
}

int find_participant(const char *id)
{
    int i;
    for(i=0;i<C.participant_count;i++)
        if(strcmp(C.participants[i].id,id)==0) return i;
    return -1;
}

int create_table(const char *name)
{
    int n=C.table_count;
    if(n>=MAX_TABLES) return -1;
    sprintf(C.tables[n].id,"TABLE-%03d",n+1);
    copy_text(C.tables[n].name,name,40);
    C.tables[n].record_count=0;
    C.tables[n].locked=0;
    C.table_count++;
    return n;
}

int register_participant(const char *name,const char *type)
{
    int n=C.participant_count;
    if(n>=MAX_PARTICIPANTS) return -1;
    sprintf(C.participants[n].id,"P-%03d",n+1);
    copy_text(C.participants[n].name,name,40);
    copy_text(C.participants[n].type,type,12);
    C.participants[n].active=1;
    C.participant_count++;
    return n;
}

int add_role(const char *name)
{
    int n=C.role_count;
    if(n>=MAX_ROLES) return -1;
    sprintf(C.roles[n].id,"ROLE-%03d",n+1);
    copy_text(C.roles[n].name,name,40);
    C.roles[n].capabilities[0]=0;
    C.roles[n].permissions[0]=0;
    C.role_count++;
    return n;
}

int grant_access(const char *participant,const char *table,const char *operation,
                 const char *authority)
{
    int n=C.grant_count;
    if(n>=MAX_GRANTS) return 0;
    sprintf(C.grants[n].id,"GRANT-%03d",n+1);
    copy_text(C.grants[n].participant_id,participant,32);
    C.grants[n].source_table[0]=0;
    copy_text(C.grants[n].destination_table,table,32);
    copy_text(C.grants[n].operation,operation,24);
    copy_text(C.grants[n].scope,"TABLE",80);
    copy_text(C.grants[n].granting_authority,authority,40);
    copy_text(C.grants[n].state,"AUTHORIZED",16);
    C.grant_count++;
    return 1;
}

int authorized(const char *participant,const char *operation,const char *table)
{
    int i;
    for(i=0;i<C.grant_count;i++)
        if(strcmp(C.grants[i].participant_id,participant)==0 &&
           strcmp(C.grants[i].operation,operation)==0 &&
           strcmp(C.grants[i].state,"AUTHORIZED")==0 &&
           strcmp(C.grants[i].destination_table,table)==0)
            return 1;
    return 0;
}

int append_record(const char *actor,const char *table_id,const char *data,
                  const char *classification,int explicit_auth)
{
    int p=find_participant(actor);
    int t=find_table(table_id);
    int h,a;
    RECORD *r;

    if(p<0 || t<0) return 0;
    if(C.tables[t].locked) return 0;

    if(strcmp(C.participants[p].type,"AI")==0 && !explicit_auth)
        return 0;

    if(C.tables[t].record_count>=MAX_RECORDS) return 0;

    r=&C.tables[t].records[C.tables[t].record_count];
    sprintf(r->id,"REC-%03d",C.tables[t].record_count+1);
    copy_text(r->data,data,MAX_TEXT);
    copy_text(r->provenance.created_by,actor,40);
    r->provenance.timestamp=stamp();
    copy_text(r->provenance.table_id,table_id,32);
    sprintf(r->provenance.operation_id,"OP-%03d",C.history_count+1);
    copy_text(r->classification,classification,16);
    copy_text(r->novelty,"New",16);
    r->importance=0;
    r->relevance=0;
    r->confidence=0;
    C.tables[t].record_count++;

    h=C.history_count;
    if(h<MAX_HISTORY)
    {
        sprintf(C.history[h].id,"VER-%03d",h+1);
        copy_text(C.history[h].operation_id,r->provenance.operation_id,32);
        copy_text(C.history[h].actor,actor,32);
        copy_text(C.history[h].reason,"APPEND",40);
        C.history[h].timestamp=stamp();
        C.history_count++;
    }

    a=C.audit_count;
    if(a<MAX_AUDIT)
    {
        sprintf(C.audit[a].id,"AUD-%03d",a+1);
        copy_text(C.audit[a].operation,"APPEND",24);
        copy_text(C.audit[a].actor,actor,32);
        copy_text(C.audit[a].table_id,table_id,32);
        copy_text(C.audit[a].version_id,C.history[h].id,32);
        C.audit[a].timestamp=stamp();
        C.audit_count++;
    }

    C.version++;
    return 1;
}

int build_context(const char *actor,const char *table,const char *task)
{
    int t=find_table(table);
    int p=find_participant(actor);
    int n=C.context_count;
    int i;
    if(t<0 || p<0 || n>=MAX_CONTEXT) return 0;

    sprintf(C.contexts[n].id,"CTX-%03d",n+1);
    copy_text(C.contexts[n].table_id,table,32);
    copy_text(C.contexts[n].actor_id,actor,32);
    copy_text(C.contexts[n].task,task,MAX_TEXT);
    C.contexts[n].record_count=C.tables[t].record_count;
    if(C.contexts[n].record_count>64) C.contexts[n].record_count=64;
    for(i=0;i<C.contexts[n].record_count;i++)
        copy_text(C.contexts[n].record_ids[i],C.tables[t].records[i].id,32);
    C.context_count++;
    return 1;
}

int save_commons(void)
{
    FILE *f=fopen(STATE_FILE,"wb");
    if(!f) return 0;
    if(fwrite("COM1",4,1,f)!=1){fclose(f);return 0;}
    if(fwrite(&C,sizeof(C),1,f)!=1){fclose(f);return 0;}
    fclose(f);
    return 1;
}

int load_commons(void)
{
    FILE *f=fopen(STATE_FILE,"rb");
    char magic[4];
    if(!f) return 0;
    if(fread(magic,4,1,f)!=1 || memcmp(magic,"COM1",4)!=0)
    { fclose(f); return 0; }
    if(fread(&C,sizeof(C),1,f)!=1)
    { fclose(f); return 0; }
    fclose(f);
    return 1;
}

void status(void)
{
    printf("\nTHE COMMONS %d\n",C.version);
    printf("Tables:       %d\n",C.table_count);
    printf("Participants: %d\n",C.participant_count);
    printf("Roles:        %d\n",C.role_count);
    printf("Grants:       %d\n",C.grant_count);
    printf("Contexts:     %d\n",C.context_count);
    printf("History:      %d\n",C.history_count);
    printf("Audit:        %d\n",C.audit_count);
    printf("Rules:        %d\n\n",C.rule_count);
}

void list_tables(void)
{
    int i;
    for(i=0;i<C.table_count;i++)
        printf("%s  %s  records:%d\n",C.tables[i].id,C.tables[i].name,C.tables[i].record_count);
}

void list_participants(void)
{
    int i;
    for(i=0;i<C.participant_count;i++)
        printf("%s  %s  %s\n",C.participants[i].id,C.participants[i].name,C.participants[i].type);
}

void list_rules(void)
{
    int i;
    for(i=0;i<C.rule_count;i++)
        if(C.rules[i].enabled) printf("%s: %s\n",C.rules[i].name,C.rules[i].text);
}

void list_history(void)
{
    int i;
    for(i=0;i<C.history_count;i++)
        printf("%s  %s  %s  %s\n",C.history[i].id,C.history[i].operation_id,C.history[i].actor,C.history[i].reason);
}

void init_council(void)
{
    CouncilMemberCount=4;
    strcpy(CouncilMembers[0].id,"ELDER-001");
    strcpy(CouncilMembers[0].name,"Archivist");
    strcpy(CouncilMembers[0].perspective,"evidence and provenance");
    strcpy(CouncilMembers[1].id,"ELDER-002");
    strcpy(CouncilMembers[1].name,"Steward");
    strcpy(CouncilMembers[1].perspective,"governance and continuity");
    strcpy(CouncilMembers[2].id,"ELDER-003");
    strcpy(CouncilMembers[2].name,"Skeptic");
    strcpy(CouncilMembers[2].perspective,"challenge and uncertainty");
    strcpy(CouncilMembers[3].id,"ELDER-004");
    strcpy(CouncilMembers[3].name,"Pragmatist");
    strcpy(CouncilMembers[3].perspective,"implementation and consequences");
}

void init_thinktank(void)
{
    AnalystCount=5;
    strcpy(Analysts[0].id,"AN-001"); strcpy(Analysts[0].name,"Architect"); strcpy(Analysts[0].perspective,"system structure");
    strcpy(Analysts[1].id,"AN-002"); strcpy(Analysts[1].name,"Engineer"); strcpy(Analysts[1].perspective,"implementation");
    strcpy(Analysts[2].id,"AN-003"); strcpy(Analysts[2].name,"Researcher"); strcpy(Analysts[2].perspective,"evidence");
    strcpy(Analysts[3].id,"AN-004"); strcpy(Analysts[3].name,"Devils Advocate"); strcpy(Analysts[3].perspective,"failure modes");
    strcpy(Analysts[4].id,"AN-005"); strcpy(Analysts[4].name,"Pragmatist"); strcpy(Analysts[4].perspective,"operational usefulness");
}

void list_council(void)
{
    int i;
    printf("ELDER COUNCIL\n");
    for(i=0;i<CouncilMemberCount;i++)
        printf("%s  %s  %s\n",CouncilMembers[i].id,CouncilMembers[i].name,CouncilMembers[i].perspective);
}

void list_thinktank(void)
{
    int i;
    printf("THINK TANK\n");
    for(i=0;i<AnalystCount;i++)
        printf("%s  %s  %s\n",Analysts[i].id,Analysts[i].name,Analysts[i].perspective);
}

void help(void)
{
    printf("\nCOMMONS COMMANDS\n");
    printf("STATUS\nTABLES\nPARTICIPANTS\nRULES\nHISTORY\n");
    printf("COUNCIL\nTHINKTANK\nSAVE\nLOAD\n");
    printf("NEW TABLE <name>\nNEW PERSON <name> <HUMAN|AI>\nEXIT\n\n");
}

int main(void)
{
    char line[256];
    char name[80];
    char type[20];

    init_commons();
    init_council();
    init_thinktank();

    printf("THE COMMONS - SIMPLE 486 DOS EDITION\n");
    printf("AI brings the intelligence; the Commons provides the table.\n");
    printf("Type HELP.\n");

    while(1)
    {
        printf("> ");
        if(!gets(line)) break;

        if(strcmp(line,"EXIT")==0 || strcmp(line,"QUIT")==0) break;
        if(strcmp(line,"STATUS")==0){status();continue;}
        if(strcmp(line,"TABLES")==0){list_tables();continue;}
        if(strcmp(line,"PARTICIPANTS")==0){list_participants();continue;}
        if(strcmp(line,"RULES")==0){list_rules();continue;}
        if(strcmp(line,"HISTORY")==0){list_history();continue;}
        if(strcmp(line,"COUNCIL")==0){list_council();continue;}
        if(strcmp(line,"THINKTANK")==0){list_thinktank();continue;}
        if(strcmp(line,"SAVE")==0){printf(save_commons()?"SAVED\n":"SAVE FAILED\n");continue;}
        if(strcmp(line,"LOAD")==0){printf(load_commons()?"LOADED\n":"LOAD FAILED\n");continue;}
        if(strcmp(line,"HELP")==0){help();continue;}

        if(strncmp(line,"NEW TABLE ",10)==0)
        {
            strcpy(name,line+10);
            printf(create_table(name)>=0?"TABLE CREATED\n":"TABLE LIMIT REACHED\n");
            continue;
        }

        if(strncmp(line,"NEW PERSON ",11)==0)
        {
            if(sscanf(line+11,"%79s %19s",name,type)==2)
                printf(register_participant(name,type)>=0?"PARTICIPANT CREATED\n":"PARTICIPANT LIMIT REACHED\n");
            else printf("USE: NEW PERSON NAME HUMAN|AI\n");
            continue;
        }

        printf("UNKNOWN COMMAND\n");
    }

    save_commons();
    return 0;
}
