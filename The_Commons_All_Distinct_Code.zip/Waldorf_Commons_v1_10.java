/*
 * Commons + Waldorf v1.10 — Java port
 *
 * Standard-library-only implementation of the updated Commons + Waldorf
 * reference program. Commons remains domain-neutral; Waldorf is the attached
 * table-steward/domain layer.
 *
 * Includes:
 *   - CT/BCTD command compatibility
 *   - CCB campaign snapshots
 *   - D0 deep-save cascade
 *   - versioned state/history
 *   - integrity checks
 *   - atomic rollback with sequestered displaced history
 *   - rollback failure-state capture
 *   - permissions and hard-stop behavior
 *
 * Save this file as Waldorf_Commons_v1_10.java when compiling.
 */

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

public class Waldorf_Commons_v1_10 {
    static final int MAX_DIRECTORY_BYTES = 32_000;

    static long now() { return System.currentTimeMillis(); }

    @SuppressWarnings("unchecked")
    static <T> T deepCopy(T value) {
        if (value instanceof Map<?, ?>) {
            Map<String,Object> out = new LinkedHashMap<>();
            for (Map.Entry<?,?> e : ((Map<?,?>) value).entrySet())
                out.put(String.valueOf(e.getKey()), deepCopy(e.getValue()));
            return (T) out;
        }
        if (value instanceof List<?>) {
            List<Object> out = new ArrayList<>();
            for (Object x : (List<?>) value) out.add(deepCopy(x));
            return (T) out;
        }
        return value;
    }

    static String stableJson(Object value) { return Json.stringify(value, true); }

    static String crc(Object value, int length) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(stableJson(value).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.substring(0, length).toUpperCase(Locale.ROOT);
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    static String id() { return UUID.randomUUID().toString(); }

    static class Participant {
        final String participantId;
        final String kind;
        Participant(String participantId) { this(participantId, "OTHER"); }
        Participant(String participantId, String kind) { this.participantId = participantId; this.kind = kind; }
    }

    static class Authorization {
        final Map<String,Map<String,Set<String>>> tableRoles = new LinkedHashMap<>();
        final Set<String> systemRollbackRoles = new HashSet<>(Collections.singletonList("SYSTEM"));
        final Set<String> systemRecallRoles = new HashSet<>(Collections.singletonList("SYSTEM"));

        void grant(String tableId, String participantId, String permission) {
            tableRoles.computeIfAbsent(tableId, k -> new LinkedHashMap<>())
                      .computeIfAbsent(participantId, k -> new HashSet<>()).add(permission);
        }
        void revoke(String tableId, String participantId, String permission) {
            tableRoles.computeIfAbsent(tableId, k -> new LinkedHashMap<>())
                      .computeIfAbsent(participantId, k -> new HashSet<>()).remove(permission);
        }
        boolean allowed(String tableId, String actor, String permission) {
            return tableRoles.getOrDefault(tableId, Collections.emptyMap())
                    .getOrDefault(actor, Collections.emptySet()).contains(permission);
        }
    }

    static class HistoryVersion {
        final String versionId;
        final int version;
        final long timestamp;
        Map<String,Object> data;
        String integrity;
        final String parentVersionId;
        HistoryVersion(String versionId, int version, long timestamp, Map<String,Object> data,
                       String integrity, String parentVersionId) {
            this.versionId=versionId; this.version=version; this.timestamp=timestamp;
            this.data=data; this.integrity=integrity; this.parentVersionId=parentVersionId;
        }
    }

    static class CommonsTable {
        final String tableId, name;
        Map<String,Object> state = new LinkedHashMap<>();
        final List<HistoryVersion> history = new ArrayList<>();
        String activeVersionId;
        final Map<String,Map<String,Object>> sequestered = new LinkedHashMap<>();
        final List<Map<String,Object>> rollbackEvents = new ArrayList<>();
        final Map<String,Object> rollbackPolicy = new LinkedHashMap<>();
        final Set<String> participants = new HashSet<>();
        final Authorization auth = new Authorization();

        CommonsTable(String tableId, String name) {
            this.tableId=tableId; this.name=name;
            rollbackPolicy.put("table_consensus_required", true);
            rollbackPolicy.put("allowed_state_categories", Arrays.asList("table_state","conversation_state","domain_state"));
            commitInitial();
        }

        HistoryVersion newVersion(Map<String,Object> data, String parent, Integer version) {
            int v = version != null ? version : (history.isEmpty() ? 1 : history.get(history.size()-1).version + 1);
            HistoryVersion h = new HistoryVersion(id(), v, now(), deepCopy(data), crc(data,8), parent);
            history.add(h); activeVersionId=h.versionId; return h;
        }
        void commitInitial() { newVersion(new LinkedHashMap<>(), null, null); }
        HistoryVersion current() {
            for (HistoryVersion h: history) if (h.versionId.equals(activeVersionId)) return h;
            throw new IllegalStateException("ACTIVE_VERSION_NOT_FOUND");
        }
        HistoryVersion version(String versionId) {
            for (HistoryVersion h: history)
                if (h.versionId.equals(versionId) || String.valueOf(h.version).equals(versionId)) return h;
            return null;
        }
        boolean verify(HistoryVersion h) { return h.integrity.equals(crc(h.data,8)); }

        HistoryVersion saveState(String actor, Map<String,Object> data, String category) {
            if (!auth.allowed(tableId, actor, "WRITE") && !"SYSTEM".equals(actor))
                throw new SecurityException("WRITE_NOT_AUTHORIZED");
            Map<String,Object> proposed=deepCopy(state); proposed.put(category, deepCopy(data));
            if (stableJson(proposed).getBytes(StandardCharsets.UTF_8).length > MAX_DIRECTORY_BYTES)
                throw new IllegalArgumentException("OVERFLOW");
            state=proposed; return newVersion(state, activeVersionId, null);
        }

        Map<String,Object> rollback(String actor, String targetVersionId, boolean systemPriority,
                                    boolean consensus, String reason, String expectedCurrentVersionId) {
            HistoryVersion before=current();
            if (expectedCurrentVersionId != null && !before.versionId.equals(expectedCurrentVersionId))
                return rollbackFail(actor,"ROLLBACK_STALE_STATE",targetVersionId,before,reason);
            boolean authorized = systemPriority ? "SYSTEM".equals(actor)
                    : consensus && ("SYSTEM".equals(actor) || auth.allowed(tableId,actor,"ROLLBACK"));
            if (!authorized) return rollbackFail(actor,"ROLLBACK_ACCESS_DENIED",targetVersionId,before,reason);
            HistoryVersion target=version(targetVersionId);
            if (target==null) return rollbackFail(actor,"ROLLBACK_VERSION_NOT_FOUND",targetVersionId,before,reason);
            if (!verify(target)) return rollbackFail(actor,"ROLLBACK_INTEGRITY_FAILURE",targetVersionId,before,reason);
            if (target.versionId.equals(before.versionId)) return rollbackFail(actor,"ROLLBACK_NOOP",targetVersionId,before,reason);

            String eventId=id();
            Map<String,Object> pre=new LinkedHashMap<>();
            pre.put("active",deepCopy(before.data)); pre.put("active_version_id",before.versionId);
            pre.put("timestamp",now()); pre.put("target",target.versionId);
            List<Map<String,Object>> displaced=new ArrayList<>();
            List<String> displacedIds=new ArrayList<>();
            for (HistoryVersion h:history) if(h.version>target.version){ displacedIds.add(h.versionId); displaced.add(historyMap(h)); }
            Map<String,Object> sq=new LinkedHashMap<>();
            sq.put("original_table_id",tableId); sq.put("rollback_event_id",eventId);
            sq.put("displaced_version_ids",displacedIds); sq.put("history",displaced);
            sq.put("access","EXPLICIT_HISTORICAL_ONLY"); sq.put("ai_working_context",false); sq.put("retention","SEPARATE_POLICY");
            sequestered.put(eventId,sq);
            try {
                HistoryVersion branch=newVersion(target.data,target.versionId,null);
                branch.data=deepCopy(target.data); branch.integrity=crc(branch.data,8); state=deepCopy(branch.data);
                Map<String,Object> ev=new LinkedHashMap<>();
                ev.put("event_id",eventId); ev.put("actor",actor); ev.put("target_version",target.versionId);
                ev.put("previous_active_version",before.versionId); ev.put("resulting_version",branch.versionId);
                ev.put("timestamp",now()); ev.put("reason",reason); ev.put("sequestered_record",eventId); ev.put("system_priority",systemPriority);
                rollbackEvents.add(ev);
                return mapOf("status","ROLLBACK_SUCCESS","event_id",eventId,"previous",before.versionId,
                        "target",target.versionId,"result",branch.versionId,"sequestered",eventId);
            } catch(Exception exc) {
                String failureId=id(); Map<String,Object> fail=new LinkedHashMap<>();
                fail.put("type","ROLLBACK_FAILURE_SAVE"); fail.put("event_id",eventId); fail.put("failure",exc.toString());
                fail.put("pre_state",pre); fail.put("timestamp",now()); fail.put("access","SYSTEM_ONLY"); sequestered.put(failureId,fail);
                HistoryVersion working=earliestWorking(); state=deepCopy(working.data); activeVersionId=working.versionId;
                rollbackEvents.add(mapOf("event_id",eventId,"actor",actor,"result","ROLLBACK_FAILED_RESET",
                        "failure_save",failureId,"reset_version",working.versionId,"timestamp",now()));
                return mapOf("status","ROLLBACK_FAILED","failure_save",failureId,"reset_version",working.versionId);
            }
        }
        HistoryVersion earliestWorking(){ for(HistoryVersion h:history) if(verify(h)) return h; throw new IllegalStateException("NO_WORKING_VERSION"); }
        Map<String,Object> rollbackFail(String actor,String status,String target,HistoryVersion before,String reason){
            String sid=id(); Map<String,Object> s=new LinkedHashMap<>();
            s.put("type","ROLLBACK_FAILURE_SAVE"); s.put("status",status); s.put("timestamp",now());
            s.put("pre_state",deepCopy(before.data)); s.put("pre_version",before.versionId); s.put("target",target); s.put("reason",reason); s.put("access","SYSTEM_ONLY");
            sequestered.put(sid,s); rollbackEvents.add(mapOf("event_id",sid,"actor",actor,"result",status,"timestamp",now(),"saved_failure_state",sid));
            return mapOf("status",status,"failure_save",sid,"active",before.versionId);
        }
        static Map<String,Object> historyMap(HistoryVersion h){ return mapOf("version_id",h.versionId,"version",h.version,"timestamp",h.timestamp,"data",deepCopy(h.data),"integrity",h.integrity,"parent_version_id",h.parentVersionId); }
    }

    static class CCB {
        Map<String,Object> root; final List<Map<String,Object>> arcs=new ArrayList<>(), sessions=new ArrayList<>(), snapshots=new ArrayList<>();
        Map<String,Object> init(String campaignId){ root=mapOf("id",campaignId,"system","CCB","created",now(),"status","ACTIVE"); return root; }
        Map<String,Object> arcNew(String name){ Map<String,Object>x=mapOf("id",String.format("ARC_%03d",arcs.size()+1),"parent",root.get("id"),"name",name);arcs.add(x);return x; }
        Map<String,Object> sessionNew(String location){ Object parent=arcs.isEmpty()?root.get("id"):arcs.get(arcs.size()-1).get("id");Map<String,Object>x=mapOf("id",String.format("SES_%03d",sessions.size()+1),"parent",parent,"location",location,"date_real",now());sessions.add(x);return x; }
        Map<String,Object> snapshot(String trigger,Map<String,Object> state,long entry){ Object parent=!sessions.isEmpty()?sessions.get(sessions.size()-1).get("id"):(root==null?null:root.get("id")); Map<String,Object>prev=snapshots.isEmpty()?new LinkedHashMap<>():castMap(snapshots.get(snapshots.size()-1).get("data"));Map<String,Object>delta=new LinkedHashMap<>();for(String k:state.keySet())if(!Objects.equals(prev.get(k),state.get(k)))delta.put(k,state.get(k));Map<String,Object>x=mapOf("id",String.format("SNAP_%03d",snapshots.size()+1),"parent",parent,"trigger",trigger,"timestamp",entry,"crc",crc(state,4),"data",delta);snapshots.add(x);return x; }
        Object get(String snapId,String field){ Map<String,Object>s=null;for(Map<String,Object>x:snapshots)if(snapId.equals(x.get("id")))s=x;if(s==null)return null;String[]key=field.split("\\.");Map<String,Object>cur=s;while(cur!=null){Object obj=cur.get("data");for(String k:key){if(!(obj instanceof Map)||!((Map<?,?>)obj).containsKey(k)){obj=null;break;}obj=((Map<?,?>)obj).get(k);}if(obj!=null)return obj;Object p=cur.get("parent");cur=findById(p);}return null; }
        Map<String,Object>findById(Object id){if(id==null)return null;for(Map<String,Object>x:snapshots)if(id.equals(x.get("id")))return x;for(Map<String,Object>x:sessions)if(id.equals(x.get("id")))return x;for(Map<String,Object>x:arcs)if(id.equals(x.get("id")))return x;return root!=null&&id.equals(root.get("id"))?root:null;}
        Map<String,Object> diff(String a,String b){Map<String,Object>aa=findById(a),bb=findById(b);if(aa==null||bb==null)throw new IllegalArgumentException("SNAPSHOT_NOT_FOUND");Map<String,Object>am=castMap(aa.get("data")),bm=castMap(bb.get("data"));Set<String>keys=new LinkedHashSet<>(am.keySet());keys.addAll(bm.keySet());Map<String,Object>out=new LinkedHashMap<>();for(String k:keys)if(!Objects.equals(am.get(k),bm.get(k)))out.put(k,Arrays.asList(am.get(k),bm.get(k)));return out;}
    }

    static class WaldorfOverlay {
        final String NAME="Waldorf the Game Masters Servant", ALIAS="D20CAD-ID", VER="1.2";
        String BOOT="UNLOCKED"; final String SYS_CRC="SYS002"; int AUTO_DEBUG=0,DEBUG_MODE=0,MONITOR_HALT=0;
        final Map<String,Object> goldfishBrain=new LinkedHashMap<>(); final Map<String,Map<String,Object>> retention=new LinkedHashMap<>();
        final Map<String,Map<String,Object>> dirs; final List<String> LAST_5_CT_COMMANDS=new ArrayList<>(); final CCB ccb=new CCB();
        final CommonsTable table=new CommonsTable("WALDORF-TABLE","Waldorf");

        WaldorfOverlay(){
            goldfishBrain.put("readall",null);goldfishBrain.put("crc_checks",new ArrayList<>());goldfishBrain.put("debug_logs",new ArrayList<>());goldfishBrain.put("system_logs",new ArrayList<>());goldfishBrain.put("last_error",null);goldfishBrain.put("monitors",new ArrayList<>());goldfishBrain.put("gm_context",null);goldfishBrain.put("retention_log",new ArrayList<>());goldfishBrain.put("deep_save_log",new ArrayList<>());
            retention.put("D0",mapOf("HISTORY",5,"L1",10,"L2",20,"L3",30,"L4",40,"L5",999999));
            retention.put("D1",mapOf("HISTORY",20,"CLEAR","PROTECT"));retention.put("D2",mapOf("HISTORY",20,"CLEAR","PROTECT"));retention.put("D3",mapOf("HISTORY",20,"CLEAR","PROTECT"));retention.put("D4",mapOf("HISTORY",20,"CLEAR","PROTECT"));retention.put("D5",mapOf("HISTORY",20,"TIMELINE",50,"CLEAR","PROTECT"));retention.put("D6",mapOf("HISTORY",20,"SESSION","PURGE","CLEAR","PROTECT"));
            dirs=defaultDirs(); for(String d:dirs.keySet())dirs.get(d).put("CRC",crc(dirs.get(d).get("DATA"),5));
            table.auth.grant(table.tableId,"SYSTEM","WRITE");table.auth.grant(table.tableId,"SYSTEM","ROLLBACK");syncTableState();
        }

        Map<String,Map<String,Object>> defaultDirs(){
            Map<String,Map<String,Object>>m=new LinkedHashMap<>();
            m.put("D0",mapOf("VIEW",0,"EDIT",0,"CRC",null,"NAME","deep_save","VER",1,"DATA",mapOf("L1",new LinkedHashMap<>(),"L2",new LinkedHashMap<>(),"L3",new LinkedHashMap<>(),"L4",new LinkedHashMap<>(),"L5",new LinkedHashMap<>(),"meta",mapOf("last_snapshot",0,"cascade_count",0)),"SCHEMA","deep","HISTORY",new ArrayList<>()));
            m.put("D1",mapOf("VIEW",1,"EDIT",1,"CRC",null,"NAME","chars","VER",1,"DATA",mapOf("schema","pc","entries",mapOf("[SAVE]template",mapOf("name","","class","","level",1,"stats",mapOf("str",10,"dex",10,"con",10,"int",10,"wis",10,"cha",10),"hp",mapOf("current",10,"max",10),"ac",10,"inventory",new ArrayList<>(),"skills",new LinkedHashMap<>(),"conditions",new ArrayList<>()))),"SCHEMA","character","HISTORY",new ArrayList<>()));
            m.put("D2",mapOf("VIEW",1,"EDIT",1,"CRC",null,"NAME","world","VER",1,"DATA",mapOf("[SAVE]system","d20_srd5.1","campaign","New Campaign","time",mapOf("day",1,"hour",8,"season","Spring"),"weather","Clear","locations",mapOf("tavern",mapOf("name","The Drunken Dragon","npcs",new ArrayList<>(),"notes","Starting location")),"factions",new LinkedHashMap<>(),"house_rules",new ArrayList<>(),"ability_scores",Arrays.asList("str","dex","con","int","wis","cha")),"SCHEMA","world","HISTORY",new ArrayList<>()));
            m.put("D3",mapOf("VIEW",1,"EDIT",1,"CRC",null,"NAME","npcs","VER",1,"DATA",mapOf("schema","npc","entries",mapOf("[SAVE]bartender",mapOf("name","Grek Ironjaw","role","Bartender","disposition","friendly","location","tavern","secrets",Arrays.asList("Owes money to thieves guild"),"stats",mapOf("hp",15,"ac",11),"notes","Knows local rumors"))),"SCHEMA","npc","HISTORY",new ArrayList<>()));
            m.put("D4",mapOf("VIEW",1,"EDIT",1,"CRC",null,"NAME","items","VER",1,"DATA",mapOf("schema","item","entries",mapOf("[SAVE]healing_potion",mapOf("name","Potion of Healing","type","consumable","rarity","common","effect","2d4+2 healing","value","50gp","attunement",false))),"SCHEMA","item","HISTORY",new ArrayList<>()));
            m.put("D5",mapOf("VIEW",1,"EDIT",1,"CRC",null,"NAME","events","VER",1,"DATA",mapOf("schema","event","timeline",new ArrayList<>(),"active_quests",mapOf("[SAVE]q1",mapOf("title","Rat Problem","giver","bartender","objective","Clear rats from cellar","reward","20gp + free room","status","active")),"triggers",new LinkedHashMap<>()),"SCHEMA","event","HISTORY",new ArrayList<>()));
            m.put("D6",mapOf("VIEW",1,"EDIT",1,"CRC",null,"NAME","notes","VER",1,"DATA",mapOf("markers",new LinkedHashMap<>(),"session_points",new ArrayList<>()),"SCHEMA","note","HISTORY",new ArrayList<>()));
            return m;
        }
        void log(String e){((List<Object>)goldfishBrain.get("system_logs")).add(now()+"|"+e);}
        boolean saveKey(Object k){return String.valueOf(k).startsWith("[SAVE]");}
        Object extractSave(Object x){
            if(x instanceof Map){Map<String,Object>r=new LinkedHashMap<>();for(Map.Entry<?,?>e:((Map<?,?>)x).entrySet()){String k=String.valueOf(e.getKey());Object v=e.getValue();if(saveKey(k))r.put(k,deepCopy(v));else if(v instanceof Map||v instanceof List){Object q=extractSave(v);if(q!=null)r.put(k,q);}}return r.isEmpty()?null:r;}
            if(x instanceof List){List<Object>r=new ArrayList<>();for(Object i:(List<?>)x){Object q=extractSave(i);if(q!=null)r.add(q);}return r.isEmpty()?null:r;}return null;
        }
        void update(String d){Map<String,Object>x=dirs.get(d);List<Object>h=(List<Object>)x.get("HISTORY");h.add(mapOf("VER",x.get("VER"),"DATA",deepCopy(x.get("DATA")),"CRC",x.get("CRC")));x.put("VER",((Number)x.get("VER")).intValue()+1);x.put("CRC",crc(x.get("DATA"),5));prune(d);syncTableState();}
        void prune(String d){Map<String,Object>x=dirs.get(d);List<Object>h=(List<Object>)x.get("HISTORY");int m=((Number)retention.get(d).get("HISTORY")).intValue();if(h.size()>m){List<Object>protectedH=new ArrayList<>(),other=new ArrayList<>();for(Object o:h){if(extractSave(((Map<String,Object>)o).get("DATA"))!=null)protectedH.add(o);else other.add(o);}int keep=Math.max(0,m-protectedH.size());List<Object>out=new ArrayList<>(protectedH);if(other.size()>keep)other=other.subList(other.size()-keep,other.size());out.addAll(other);x.put("HISTORY",out);}}
        void cascade(){Map<String,Object>d=castMap(dirs.get("D0").get("DATA"));for(int i=1;i<=4;i++){String a="L"+i,b="L"+(i+1);int limit=((Number)retention.get("D0").get(a)).intValue();Map<String,Object>src=castMap(d.get(a));if(src.size()>limit){List<String>keys=new ArrayList<>(src.keySet());keys.sort(Comparator.comparingLong(k->{Object v=src.get(k);if(v instanceof Map&&((Map<?,?>)v).get("_timestamp") instanceof Number)return ((Number)((Map<?,?>)v).get("_timestamp")).longValue();return 0;}));int n=src.size()-limit;Map<String,Object>dst=castMap(d.get(b));for(String k:keys){if(n<=0)break;if(!saveKey(k)){dst.put(k,src.remove(k));n--;}}}}castMap(d.get("meta")).put("cascade_count",((Number)castMap(d.get("meta")).get("cascade_count")).intValue()+1);dirs.get("D0").put("CRC",crc(d,5));}
        String deepSnapshot(){Map<String,Object>snap=mapOf("_timestamp",now());for(String k:Arrays.asList("D1","D2","D3","D4","D5","D6")){Object x=extractSave(dirs.get(k).get("DATA"));if(x!=null)snap.put(k,x);}String key="snapshot_"+now();Map<String,Object>d=castMap(dirs.get("D0").get("DATA"));castMap(d.get("L1")).put(key,snap);castMap(d.get("meta")).put("last_snapshot",now());cascade();((List<Object>)goldfishBrain.get("deep_save_log")).add(key);log("DEEP|SNAPSHOT|"+key);return key;}
        void syncTableState(){Map<String,Object>ds=new LinkedHashMap<>();for(String k:dirs.keySet()){Map<String,Object>v=dirs.get(k);ds.put(k,mapOf("VER",v.get("VER"),"CRC",v.get("CRC"),"DATA",deepCopy(v.get("DATA"))));}table.state=mapOf("directories",ds);}
        String read(String d){Map<String,Object>x=dirs.get(d);if(((Number)x.get("VIEW")).intValue()==0)return "ERROR|VIEW_DENIED|"+d;return "READ|OK|"+d+"|DATA="+Json.stringify(x.get("DATA"),false);}
        String ct(String s){
            if(MONITOR_HALT!=0)return "D20CAD-ID<ERROR|HALT|BOOT=LOCKED>";
            if(s==null||!s.startsWith("CT>")){goldfishBrain.put("last_error","SYNTAX");return "D20CAD-ID<ERROR|SYNTAX|M5>";}
            LAST_5_CT_COMMANDS.add(s);while(LAST_5_CT_COMMANDS.size()>5)LAST_5_CT_COMMANDS.remove(0);String[]p=s.substring(3).split("\\|",-1);String cmd=p[0].toUpperCase(Locale.ROOT);
            try{
                if(cmd.equals("READ")&&p.length==2)return "D20CAD-ID<"+read(p[1])+">";
                if(cmd.equals("READALL")&&p.length==1){Map<String,Object>o=new LinkedHashMap<>();for(String k:dirs.keySet()){Map<String,Object>v=dirs.get(k);if(((Number)v.get("VIEW")).intValue()!=0)o.put(k,mapOf("NAME",v.get("NAME"),"VER",v.get("VER"),"CRC",v.get("CRC")));}return "D20CAD-ID<READALL|OK|DATA="+Json.stringify(o,false)+">";}
                if(cmd.equals("WRITE")&&p.length>=3){String d=p[1];if(!dirs.containsKey(d))return "D20CAD-ID<ERROR|WRITE|INVALID_DIR>";if(((Number)dirs.get(d).get("EDIT")).intValue()==0)return "D20CAD-ID<ERROR|EDIT_DENIED|"+d+">";dirs.get(d).put("DATA",mapOf("raw",String.join("|",Arrays.copyOfRange(p,2,p.length))));update(d);return "D20CAD-ID<WRITE|OK|"+d+"|CRC="+dirs.get(d).get("CRC")+">";}
                if(cmd.equals("APPEND")&&p.length>=3){String d=p[1];if(!dirs.containsKey(d))return "D20CAD-ID<ERROR|APPEND|INVALID_DIR>";if(((Number)dirs.get(d).get("EDIT")).intValue()==0)return "D20CAD-ID<ERROR|EDIT_DENIED|"+d+">";Map<String,Object>data=castMap(dirs.get(d).get("DATA"));List<Object>entries=(List<Object>)data.computeIfAbsent("entries",k->new ArrayList<>());String value=String.join("|",Arrays.copyOfRange(p,2,p.length));entries.add(value);if(stableJson(data).getBytes(StandardCharsets.UTF_8).length>MAX_DIRECTORY_BYTES){entries.remove(entries.size()-1);return "D20CAD-ID<ERROR|OVERFLOW|"+d+">";}update(d);return "D20CAD-ID<APPEND|OK|"+d+"|CRC="+dirs.get(d).get("CRC")+">";}
                if(cmd.equals("CLEAR")&&p.length==2){String d=p[1];if(!dirs.containsKey(d))return "D20CAD-ID<ERROR|NOT_FOUND>";if(((Number)dirs.get(d).get("EDIT")).intValue()==0)return "D20CAD-ID<ERROR|EDIT_DENIED|"+d+">";dirs.get(d).put("DATA",new LinkedHashMap<>());update(d);return "D20CAD-ID<CLEAR|OK|"+d+"|CRC="+dirs.get(d).get("CRC")+">";}
                if((cmd.equals("LOCK")||cmd.equals("UNLOCK"))&&p.length==2){String d=p[1];if(!dirs.containsKey(d))return "D20CAD-ID<ERROR|NOT_FOUND>";dirs.get(d).put("VIEW",cmd.equals("UNLOCK")?1:0);if(cmd.equals("LOCK"))dirs.get(d).put("EDIT",0);return "D20CAD-ID<PERM|OK|"+d+"_"+cmd+"ED>";}
                if(cmd.equals("GRANT")&&p.length==2){dirs.get(p[1]).put("EDIT",1);return "D20CAD-ID<PERM|OK|"+p[1]+"_EDIT=1>";}
                if(cmd.equals("REVOKE")&&p.length==2){dirs.get(p[1]).put("EDIT",0);return "D20CAD-ID<PERM|OK|"+p[1]+"_EDIT=0>";}
                if(cmd.equals("LOCKALL")&&p.length==1){for(String d:dirs.keySet()){dirs.get(d).put("VIEW",0);dirs.get(d).put("EDIT",0);}BOOT="LOCKED";MONITOR_HALT=1;return "D20CAD-ID<PERM|OK|ALL_LOCKED>";}
                if(cmd.equals("RECALL")&&p.length==2){String d=p[1];List<Object>h=(List<Object>)dirs.get(d).get("HISTORY");Object data=h.isEmpty()?dirs.get(d).get("DATA"):((Map<String,Object>)h.get(h.size()-1)).get("DATA");return "D20CAD-ID<RECALL|OK|DATA="+Json.stringify(data,false)+">";}
                if(cmd.equals("RECALL_VER")&&p.length==3){String d=p[1],v=p[2];for(Object o:(List<Object>)dirs.get(d).get("HISTORY"))if(String.valueOf(((Map<String,Object>)o).get("VER")).equals(v))return "D20CAD-ID<RECALL_VER|OK|DATA="+Json.stringify(((Map<String,Object>)o).get("DATA"),false)+">";if(v.equals("0"))return "D20CAD-ID<RECALL_VER|OK|BLANK>";return "D20CAD-ID<RECALL_VER|VERSION_NOT_FOUND>";}
                if(cmd.equals("DIFF")&&p.length==4)return diff(p[1],p[2],p[3]);
                if(cmd.equals("CRC_CHECK")&&p.length==2&&p[1].equalsIgnoreCase("ALL")){List<String>bad=new ArrayList<>();for(String d:dirs.keySet())if(!String.valueOf(dirs.get(d).get("CRC")).equals(crc(dirs.get(d).get("DATA"),5)))bad.add(d);if(!bad.isEmpty()){MONITOR_HALT=1;BOOT="LOCKED";return "D20CAD-ID<CRC_CHECK|FAIL|"+Json.stringify(bad,false)+">";}return "D20CAD-ID<CRC_CHECK|PASS>";}
                if(cmd.equals("DEEP")&&p.length>=2&&p[1].equalsIgnoreCase("SAVE"))return "D20CAD-ID<DEEP|SAVE|OK|"+deepSnapshot()+">";
                if(cmd.equals("STATUS")&&p.length==1)return "D20CAD-ID<STATUS|OK|BOOT="+BOOT+"|HALT="+MONITOR_HALT+"|DEEP="+((List<?>)goldfishBrain.get("deep_save_log")).size()+">";
                return "D20CAD-ID<ERROR|SYNTAX|UNKNOWN_COMMAND>";
            }catch(Exception e){goldfishBrain.put("last_error",e.toString());log("EXCEPTION|"+s+"|"+e);return "D20CAD-ID<ERROR|INTERNAL>";}
        }
        String diff(String d,String a,String b){Map<String,Object>va=new LinkedHashMap<>(),vb=new LinkedHashMap<>();for(Object o:(List<Object>)dirs.get(d).get("HISTORY")){Map<String,Object>h=(Map<String,Object>)o;if(String.valueOf(h.get("VER")).equals(a))va=castMap(h.get("DATA"));if(String.valueOf(h.get("VER")).equals(b))vb=castMap(h.get("DATA"));}if(String.valueOf(dirs.get(d).get("VER")).equals(b))vb=castMap(dirs.get(d).get("DATA"));Set<String>keys=new LinkedHashSet<>(va.keySet());keys.addAll(vb.keySet());Map<String,Object>delta=new LinkedHashMap<>();for(String k:keys)if(!Objects.equals(va.get(k),vb.get(k)))delta.put(k,Arrays.asList(va.get(k),vb.get(k)));return "D20CAD-ID<DIFF|OK|DATA="+Json.stringify(delta,false)+">";}
    }

    static class Waldorf {
        final WaldorfOverlay overlay=new WaldorfOverlay(); final Participant identity=new Participant("waldorf-agent","AI");
        final String sourceDiscipline="designated source files and current table state only";
        String handle(String message){return overlay.ct(message);}
        Map<String,Object> rollback(String target,String reason,String expected,boolean systemPriority){return overlay.table.rollback("SYSTEM",target,systemPriority,true,reason,expected);}
    }

    static Map<String,Object> mapOf(Object... kv){Map<String,Object>m=new LinkedHashMap<>();for(int i=0;i+1<kv.length;i+=2)m.put(String.valueOf(kv[i]),kv[i+1]);return m;}
    @SuppressWarnings("unchecked") static Map<String,Object> castMap(Object x){return (Map<String,Object>)x;}

    static Map<String,Object> selfTest(){
        Waldorf w=new Waldorf();WaldorfOverlay o=w.overlay;
        check(o.ct("CT>STATUS").contains("STATUS|OK"));check(o.ct("CT>READ|D1").contains("READ|OK|D1"));check(o.ct("CT>CRC_CHECK|ALL").contains("CRC_CHECK|PASS"));
        String snap=o.deepSnapshot();check(snap!=null&&!snap.isEmpty());CommonsTable t=o.table;t.auth.grant(t.tableId,"TABLE_ADMIN","ROLLBACK");t.auth.grant(t.tableId,"TABLE_ADMIN","WRITE");
        HistoryVersion v2=t.saveState("TABLE_ADMIN",mapOf("scene","A"),"table_state");HistoryVersion v3=t.saveState("TABLE_ADMIN",mapOf("scene","B"),"table_state");
        Map<String,Object>r=t.rollback("TABLE_ADMIN",v2.versionId,false,true,"test",v3.versionId);check("ROLLBACK_SUCCESS".equals(r.get("status")));check(t.current().data.equals(v2.data));check(t.sequestered.containsKey(r.get("sequestered")));
        Map<String,Object>denied=t.rollback("TABLE_ADMIN",v2.versionId,false,false,"test",null);check("ROLLBACK_ACCESS_DENIED".equals(denied.get("status")));
        check(!t.auth.tableRoles.getOrDefault(t.tableId,Collections.emptyMap()).getOrDefault("TABLE_ADMIN",Collections.emptySet()).contains("NAME_ADMIN"));
        return mapOf("status","PASS","deep_snapshot",snap,"rollback",r,"denied",denied);
    }
    static void check(boolean x){if(!x)throw new AssertionError("SELF_TEST_FAILED");}

    public static void main(String[] args){
        System.out.println(Json.stringify(selfTest(),true));
        Scanner scanner=new Scanner(System.in);
        System.out.println("Waldorf Commons v1.10 Java Interface Active");
        System.out.println("Type CT>COMMAND|ARG1|ARG2 or EXIT");
        Waldorf w=new Waldorf();
        while(true){System.out.print("CT> ");if(!scanner.hasNextLine())break;String input=scanner.nextLine().trim();if(input.equalsIgnoreCase("EXIT")){System.out.println("D20CAD-ID<SYS|SHUTDOWN>");break;}if(!input.isEmpty())System.out.println(w.handle(input));}
    }

    /* Minimal dependency-free JSON serializer. */
    static class Json {
        static String stringify(Object x, boolean sortKeys){StringBuilder s=new StringBuilder();write(x,s,sortKeys);return s.toString();}
        static void write(Object x,StringBuilder s,boolean sort){
            if(x==null){s.append("null");return;}if(x instanceof String||x instanceof Character){s.append('"').append(escape(String.valueOf(x))).append('"');return;}if(x instanceof Boolean||x instanceof Number){s.append(String.valueOf(x));return;}
            if(x instanceof Map){s.append('{');List<String>keys=new ArrayList<>();for(Object k:((Map<?,?>)x).keySet())keys.add(String.valueOf(k));if(sort)Collections.sort(keys);for(int i=0;i<keys.size();i++){if(i>0)s.append(',');String k=keys.get(i);s.append('"').append(escape(k)).append("\":");write(((Map<?,?>)x).get(k),s,sort);}s.append('}');return;}
            if(x instanceof Iterable){s.append('[');int i=0;for(Object v:(Iterable<?>)x){if(i++>0)s.append(',');write(v,s,sort);}s.append(']');return;}s.append('"').append(escape(String.valueOf(x))).append('"');
        }
        static String escape(String x){return x.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r").replace("\t","\\t");}
    }
}
