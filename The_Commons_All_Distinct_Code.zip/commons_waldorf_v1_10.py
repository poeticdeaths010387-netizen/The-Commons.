#!/usr/bin/env python3
"""Commons + Waldorf v1.10

Consolidated standard-library-only reference implementation.
Commons remains domain-neutral; Waldorf is an attached table-steward/domain layer.
Includes CT/BCTD compatibility, CCB snapshots, D0 deep-save cascade, and
atomic rollback with sequestered displaced history.
"""
from __future__ import annotations

import copy, hashlib, json, os, tempfile, time, uuid
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple

MAX_DIRECTORY_BYTES = 32_000


def now() -> float: return time.time()
def deep_copy(x): return copy.deepcopy(x)
def stable_json(x): return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
def crc(x, length=8): return hashlib.sha256(stable_json(x).encode()).hexdigest()[:length].upper()


@dataclass(frozen=True)
class Participant:
    participant_id: str
    kind: str = "OTHER"


@dataclass
class AuditEvent:
    event_id: str
    timestamp: float
    actor: str
    table_id: str
    operation: str
    result: str
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class HistoryVersion:
    version_id: str
    version: int
    timestamp: float
    data: Dict[str, Any]
    integrity: str
    parent_version_id: Optional[str] = None


class Authorization:
    """Table permissions. Identity/name administration is deliberately absent."""
    def __init__(self):
        self.table_roles: Dict[str, Dict[str, set]] = {}
        self.system_rollback_roles = {"SYSTEM"}
        self.system_recall_roles = {"SYSTEM"}

    def grant(self, table_id, participant_id, permission):
        self.table_roles.setdefault(table_id, {}).setdefault(participant_id, set()).add(permission)

    def revoke(self, table_id, participant_id, permission):
        self.table_roles.setdefault(table_id, {}).setdefault(participant_id, set()).discard(permission)

    def allowed(self, table_id, actor, permission):
        return permission in self.table_roles.get(table_id, {}).get(actor, set())


class CommonsTable:
    def __init__(self, table_id: str, name: str):
        self.table_id, self.name = table_id, name
        self.state: Dict[str, Any] = {}
        self.history: List[HistoryVersion] = []
        self.active_version_id: Optional[str] = None
        self.sequestered: Dict[str, Dict[str, Any]] = {}
        self.rollback_events: List[Dict[str, Any]] = []
        self.rollback_policy: Dict[str, Any] = {
            "table_consensus_required": True,
            "allowed_state_categories": ["table_state", "conversation_state", "domain_state"],
        }
        self.participants: set[str] = set()
        self.auth = Authorization()
        self._commit_initial()

    def _new_version(self, data, parent=None, version=None):
        if version is None: version = (self.history[-1].version + 1) if self.history else 1
        vid = str(uuid.uuid4())
        h = HistoryVersion(vid, version, now(), deep_copy(data), crc(data), parent)
        self.history.append(h)
        self.active_version_id = vid
        return h

    def _commit_initial(self): self._new_version({})

    def current(self): return next(h for h in self.history if h.version_id == self.active_version_id)

    def version(self, version_id: str):
        for h in self.history:
            if h.version_id == version_id or str(h.version) == str(version_id): return h
        return None

    def _verify(self, h): return h.integrity == crc(h.data)

    def save_state(self, actor: str, data: Dict[str, Any], category="table_state"):
        if not self.auth.allowed(self.table_id, actor, "WRITE") and actor != "SYSTEM":
            raise PermissionError("WRITE_NOT_AUTHORIZED")
        proposed = deep_copy(self.state)
        proposed[category] = deep_copy(data)
        if len(stable_json(proposed).encode()) > MAX_DIRECTORY_BYTES:
            raise ValueError("OVERFLOW")
        self.state = proposed
        return self._new_version(self.state, self.active_version_id)

    def rollback(self, actor: str, target_version_id: str, *, system_priority=False,
                 consensus=True, reason="", expected_current_version_id=None):
        """Atomic rollback. Displaced active state is sequestered, never deleted."""
        before = self.current()
        if expected_current_version_id and before.version_id != expected_current_version_id:
            return self._rollback_fail(actor, "ROLLBACK_STALE_STATE", target_version_id, before, reason)
        if system_priority:
            authorized = actor == "SYSTEM"
        else:
            authorized = consensus and (actor == "SYSTEM" or self.auth.allowed(self.table_id, actor, "ROLLBACK"))
        if not authorized:
            return self._rollback_fail(actor, "ROLLBACK_ACCESS_DENIED", target_version_id, before, reason)
        target = self.version(target_version_id)
        if target is None:
            return self._rollback_fail(actor, "ROLLBACK_VERSION_NOT_FOUND", target_version_id, before, reason)
        if not self._verify(target):
            return self._rollback_fail(actor, "ROLLBACK_INTEGRITY_FAILURE", target_version_id, before, reason)
        if target.version_id == before.version_id:
            return self._rollback_fail(actor, "ROLLBACK_NOOP", target_version_id, before, reason)

        # Save exact pre-operation state for failure recovery.
        pre = {"active": deep_copy(before.data), "active_version_id": before.version_id,
               "timestamp": now(), "target": target.version_id}
        event_id = str(uuid.uuid4())
        displaced = [h for h in self.history if h.version > target.version]
        self.sequestered[event_id] = {
            "original_table_id": self.table_id,
            "rollback_event_id": event_id,
            "displaced_version_ids": [h.version_id for h in displaced],
            "history": [asdict(h) for h in displaced],
            "access": "EXPLICIT_HISTORICAL_ONLY",
            "ai_working_context": False,
            "retention": "SEPARATE_POLICY",
        }
        try:
            # The rollback itself creates a branch version derived from target.
            branch = self._new_version(target.data, parent=target.version_id)
            branch.data = deep_copy(target.data)
            branch.integrity = crc(branch.data)
            self.state = deep_copy(branch.data)
            self.rollback_events.append({
                "event_id": event_id, "actor": actor, "target_version": target.version_id,
                "previous_active_version": before.version_id, "resulting_version": branch.version_id,
                "timestamp": now(), "reason": reason, "sequestered_record": event_id,
                "system_priority": system_priority,
            })
            return {"status": "ROLLBACK_SUCCESS", "event_id": event_id,
                    "previous": before.version_id, "target": target.version_id,
                    "result": branch.version_id, "sequestered": event_id}
        except Exception as exc:
            # Automatic save-state capture of the failure and safe reset to earliest working version.
            failure_id = str(uuid.uuid4())
            self.sequestered[failure_id] = {"type": "ROLLBACK_FAILURE_SAVE", "event_id": event_id,
                                            "failure": repr(exc), "pre_state": pre,
                                            "timestamp": now(), "access": "SYSTEM_ONLY"}
            working = self._earliest_working()
            self.state = deep_copy(working.data)
            self.active_version_id = working.version_id
            self.rollback_events.append({"event_id": event_id, "actor": actor,
                "result": "ROLLBACK_FAILED_RESET", "failure_save": failure_id,
                "reset_version": working.version_id, "timestamp": now()})
            return {"status": "ROLLBACK_FAILED", "failure_save": failure_id,
                    "reset_version": working.version_id}

    def _earliest_working(self):
        for h in self.history:
            if self._verify(h): return h
        raise RuntimeError("NO_WORKING_VERSION")

    def _rollback_fail(self, actor, status, target, before, reason):
        sid = str(uuid.uuid4())
        self.sequestered[sid] = {"type": "ROLLBACK_FAILURE_SAVE", "status": status,
            "timestamp": now(), "pre_state": deep_copy(before.data),
            "pre_version": before.version_id, "target": target, "reason": reason,
            "access": "SYSTEM_ONLY"}
        self.rollback_events.append({"event_id": sid, "actor": actor, "result": status,
                                     "timestamp": now(), "saved_failure_state": sid})
        return {"status": status, "failure_save": sid, "active": before.version_id}


class CCB:
    def __init__(self):
        self.root = None; self.arcs=[]; self.sessions=[]; self.snapshots=[]
    def init(self, campaign_id): self.root={"id":campaign_id,"system":"CCB","created":now(),"status":"ACTIVE"}; return self.root
    def arc_new(self,name):
        x={"id":f"ARC_{len(self.arcs)+1:03d}","parent":self.root["id"],"name":name}; self.arcs.append(x); return x
    def session_new(self,location):
        parent=self.arcs[-1]["id"] if self.arcs else self.root["id"]
        x={"id":f"SES_{len(self.sessions)+1:03d}","parent":parent,"location":location,"date_real":now()}; self.sessions.append(x); return x
    def snapshot(self, trigger, state, entry=0):
        parent=self.sessions[-1]["id"] if self.sessions else (self.root["id"] if self.root else None)
        prev=self.snapshots[-1]["data"] if self.snapshots else {}
        delta={k:v for k,v in state.items() if prev.get(k)!=v}
        x={"id":f"SNAP_{len(self.snapshots)+1:03d}","parent":parent,"trigger":trigger,
           "timestamp":entry,"crc":crc(state,4),"data":delta}; self.snapshots.append(x); return x
    def get(self,snap_id,field):
        s=next((x for x in self.snapshots if x["id"]==snap_id),None)
        if not s: return None
        key=field.split("."); cur=s
        while cur:
            data=cur.get("data",{})
            obj=data
            for k in key:
                if not isinstance(obj,dict) or k not in obj: obj=None; break
                obj=obj[k]
            if obj is not None:return obj
            parent=cur.get("parent")
            cur=next((z for z in self.snapshots+self.sessions+self.arcs+[self.root] if z and z.get("id")==parent),None)
        return None
    def diff(self,a,b):
        aa=next(x for x in self.snapshots if x["id"]==a); bb=next(x for x in self.snapshots if x["id"]==b)
        keys=set(aa.get("data",{}))|set(bb.get("data",{})); return {k:(aa.get("data",{}).get(k),bb.get("data",{}).get(k)) for k in keys if aa.get("data",{}).get(k)!=bb.get("data",{}).get(k)}


class WaldorfOverlay:
    def __init__(self):
        self.NAME="Waldorf the Game Masters Servant"; self.ALIAS="D20CAD-ID"; self.VER="1.2"; self.BOOT="UNLOCKED"
        self.SYS_CRC="SYS002"; self.AUTO_DEBUG=0; self.DEBUG_MODE=0; self.MONITOR_HALT=0
        self.goldfish_brain={"readall":None,"crc_checks":[],"debug_logs":[],"system_logs":[],"last_error":None,"monitors":[],"gm_context":None,"retention_log":[],"deep_save_log":[]}
        self.retention={"D0":{"HISTORY":5,"L1":10,"L2":20,"L3":30,"L4":40,"L5":999999},"D1":{"HISTORY":20,"CLEAR":"PROTECT"},"D2":{"HISTORY":20,"CLEAR":"PROTECT"},"D3":{"HISTORY":20,"CLEAR":"PROTECT"},"D4":{"HISTORY":20,"CLEAR":"PROTECT"},"D5":{"HISTORY":20,"TIMELINE":50,"CLEAR":"PROTECT"},"D6":{"HISTORY":20,"SESSION":"PURGE","CLEAR":"PROTECT"}}
        self.dirs=self._default_dirs(); self.LAST_5_CT_COMMANDS=[]
        for d in self.dirs:self.dirs[d]["CRC"]=crc(self.dirs[d]["DATA"],5)
        self.ccb=CCB()
        self.table=CommonsTable("WALDORF-TABLE","Waldorf")
        self.table.auth.grant(self.table.table_id,"SYSTEM","WRITE"); self.table.auth.grant(self.table.table_id,"SYSTEM","ROLLBACK")
        self._sync_table_state()

    def _default_dirs(self):
        return {
        "D0":{"VIEW":0,"EDIT":0,"CRC":None,"NAME":"deep_save","VER":1,"DATA":{"L1":{},"L2":{},"L3":{},"L4":{},"L5":{},"meta":{"last_snapshot":0,"cascade_count":0}},"SCHEMA":"deep","HISTORY":[]},
        "D1":{"VIEW":1,"EDIT":1,"CRC":None,"NAME":"chars","VER":1,"DATA":{"schema":"pc","entries":{"[SAVE]template":{"name":"","class":"","level":1,"stats":{"str":10,"dex":10,"con":10,"int":10,"wis":10,"cha":10},"hp":{"current":10,"max":10},"ac":10,"inventory":[],"skills":{},"conditions":[]}}},"SCHEMA":"character","HISTORY":[]},
        "D2":{"VIEW":1,"EDIT":1,"CRC":None,"NAME":"world","VER":1,"DATA":{"[SAVE]system":"d20_srd5.1","campaign":"New Campaign","time":{"day":1,"hour":8,"season":"Spring"},"weather":"Clear","locations":{"tavern":{"name":"The Drunken Dragon","npcs":[],"notes":"Starting location"}},"factions":{},"house_rules":[],"ability_scores":["str","dex","con","int","wis","cha"]},"SCHEMA":"world","HISTORY":[]},
        "D3":{"VIEW":1,"EDIT":1,"CRC":None,"NAME":"npcs","VER":1,"DATA":{"schema":"npc","entries":{"[SAVE]bartender":{"name":"Grek Ironjaw","role":"Bartender","disposition":"friendly","location":"tavern","secrets":["Owes money to thieves guild"],"stats":{"hp":15,"ac":11},"notes":"Knows local rumors"}}},"SCHEMA":"npc","HISTORY":[]},
        "D4":{"VIEW":1,"EDIT":1,"CRC":None,"NAME":"items","VER":1,"DATA":{"schema":"item","entries":{"[SAVE]healing_potion":{"name":"Potion of Healing","type":"consumable","rarity":"common","effect":"2d4+2 healing","value":"50gp","attunement":False}}},"SCHEMA":"item","HISTORY":[]},
        "D5":{"VIEW":1,"EDIT":1,"CRC":None,"NAME":"events","VER":1,"DATA":{"schema":"event","timeline":[],"active_quests":{"[SAVE]q1":{"title":"Rat Problem","giver":"bartender","objective":"Clear rats from cellar","reward":"20gp + free room","status":"active"}},"triggers":{}},"SCHEMA":"event","HISTORY":[]},
        "D6":{"VIEW":1,"EDIT":1,"CRC":None,"NAME":"notes","VER":1,"DATA":{"markers":{},"session_points":[]},"SCHEMA":"note","HISTORY":[]}}

    def _log(self,e): self.goldfish_brain["system_logs"].append(f"{now()}|{e}")
    def _save_key(self,k): return str(k).startswith("[SAVE]")
    def _extract_save(self,x):
        if isinstance(x,dict):
            r={}
            for k,v in x.items():
                if self._save_key(k): r[k]=deep_copy(v)
                elif isinstance(v,(dict,list)):
                    q=self._extract_save(v)
                    if q:r[k]=q
            return r or None
        if isinstance(x,list):
            r=[q for i in x if (q:=self._extract_save(i)) is not None]; return r or None
        return None
    def _update(self,d):
        old=deep_copy(self.dirs[d]["DATA"]); self.dirs[d]["HISTORY"].append({"VER":self.dirs[d]["VER"],"DATA":old,"CRC":self.dirs[d]["CRC"]})
        self.dirs[d]["VER"]+=1; self.dirs[d]["CRC"]=crc(self.dirs[d]["DATA"],5); self._prune(d); self._sync_table_state()
    def _prune(self,d):
        h=self.dirs[d]["HISTORY"]; m=self.retention[d].get("HISTORY",20)
        if len(h)>m:
            protected=[x for x in h if self._extract_save(x["DATA"])]; other=[x for x in h if x not in protected]
            self.dirs[d]["HISTORY"]=(protected+other[-max(0,m-len(protected)):])
    def _cascade(self):
        d=self.dirs["D0"]["DATA"]
        for i in range(1,5):
            a,b=f"L{i}",f"L{i+1}"; limit=self.retention["D0"][a]
            if len(d[a])>limit:
                for k,v in sorted(d[a].items(),key=lambda z:z[1].get("_timestamp",0))[:len(d[a])-limit]:
                    if not self._save_key(k): d[b][k]=v; del d[a][k]
        d["meta"]["cascade_count"]+=1; self.dirs["D0"]["CRC"]=crc(d,5)
    def deep_snapshot(self):
        snap={"_timestamp":now()}
        for k in ["D1","D2","D3","D4","D5","D6"]:
            x=self._extract_save(self.dirs[k]["DATA"])
            if x:snap[k]=x
        key=f"snapshot_{int(now()*1000)}"; self.dirs["D0"]["DATA"]["L1"][key]=snap; self.dirs["D0"]["DATA"]["meta"]["last_snapshot"]=now(); self._cascade(); self.goldfish_brain["deep_save_log"].append(key); self._log(f"DEEP|SNAPSHOT|{key}"); return key
    def _sync_table_state(self):
        self.table.state={"directories":{k:{"VER":v["VER"],"CRC":v["CRC"],"DATA":deep_copy(v["DATA"])} for k,v in self.dirs.items()}}

    def _read(self,d):
        if not self.dirs[d]["VIEW"]: return "ERROR|VIEW_DENIED|"+d
        return f"READ|OK|{d}|DATA="+json.dumps(self.dirs[d]["DATA"],ensure_ascii=False)
    def ct(self,s):
        if self.MONITOR_HALT:return "D20CAD-ID<ERROR|HALT|BOOT=LOCKED>"
        if not isinstance(s,str) or not s.startswith("CT>"):
            self.goldfish_brain["last_error"]="SYNTAX"; return "D20CAD-ID<ERROR|SYNTAX|M5>"
        self.LAST_5_CT_COMMANDS.append(s); self.LAST_5_CT_COMMANDS=self.LAST_5_CT_COMMANDS[-5:]
        p=s[3:].split("|"); cmd=p[0].upper()
        try:
            if cmd=="READ" and len(p)==2:return "D20CAD-ID<"+self._read(p[1])+">"
            if cmd=="READALL" and len(p)==1:return "D20CAD-ID<READALL|OK|DATA="+json.dumps({k:{"NAME":v["NAME"],"VER":v["VER"],"CRC":v["CRC"]} for k,v in self.dirs.items() if v["VIEW"]})+">"
            if cmd=="WRITE" and len(p)>=3:
                d=p[1];
                if d not in self.dirs:return "D20CAD-ID<ERROR|WRITE|INVALID_DIR>"
                if not self.dirs[d]["EDIT"]:return f"D20CAD-ID<ERROR|EDIT_DENIED|{d}>"
                self.dirs[d]["DATA"]={"raw":"|".join(p[2:])}; self._update(d); return f"D20CAD-ID<WRITE|OK|{d}|CRC={self.dirs[d]['CRC']}>"
            if cmd=="APPEND" and len(p)>=3:
                d=p[1];
                if d not in self.dirs:return "D20CAD-ID<ERROR|APPEND|INVALID_DIR>"
                if not self.dirs[d]["EDIT"]:return f"D20CAD-ID<ERROR|EDIT_DENIED|{d}>"
                self.dirs[d]["DATA"].setdefault("entries",[]).append("|".join(p[2:]));
                if len(stable_json(self.dirs[d]["DATA"]).encode())>MAX_DIRECTORY_BYTES:self.dirs[d]["DATA"]["entries"].pop(); return f"D20CAD-ID<ERROR|OVERFLOW|{d}>"
                self._update(d); return f"D20CAD-ID<APPEND|OK|{d}|CRC={self.dirs[d]['CRC']}>"
            if cmd=="CLEAR" and len(p)==2:
                d=p[1];
                if not self.dirs[d]["EDIT"]:return f"D20CAD-ID<ERROR|EDIT_DENIED|{d}>"
                self.dirs[d]["DATA"]={}; self._update(d); return f"D20CAD-ID<CLEAR|OK|{d}|CRC={self.dirs[d]['CRC']}>"
            if cmd in ("LOCK","UNLOCK") and len(p)==2:
                d=p[1]; self.dirs[d]["VIEW"]=1 if cmd=="UNLOCK" else 0; self.dirs[d]["EDIT"]=self.dirs[d]["EDIT"] if cmd=="UNLOCK" else 0; return f"D20CAD-ID<PERM|OK|{d}_{cmd}ED>"
            if cmd=="GRANT" and len(p)==2:self.dirs[p[1]]["EDIT"]=1;return f"D20CAD-ID<PERM|OK|{p[1]}_EDIT=1>"
            if cmd=="REVOKE" and len(p)==2:self.dirs[p[1]]["EDIT"]=0;return f"D20CAD-ID<PERM|OK|{p[1]}_EDIT=0>"
            if cmd=="LOCKALL" and len(p)==1:
                for d in self.dirs:self.dirs[d]["VIEW"]=self.dirs[d]["EDIT"]=0
                self.BOOT="LOCKED"; self.MONITOR_HALT=1; return "D20CAD-ID<PERM|OK|ALL_LOCKED>"
            if cmd=="RECALL" and len(p)==2:
                d=p[1]; h=self.dirs[d]["HISTORY"][-1] if self.dirs[d]["HISTORY"] else {"DATA":self.dirs[d]["DATA"]}; return "D20CAD-ID<RECALL|OK|DATA="+json.dumps(h["DATA"])+">"
            if cmd=="RECALL_VER" and len(p)==3:
                d,v=p[1],p[2]; found=next((h for h in self.dirs[d]["HISTORY"] if str(h["VER"])==v),None)
                if found:return "D20CAD-ID<RECALL_VER|OK|DATA="+json.dumps(found["DATA"])+">"
                if v=="0":return "D20CAD-ID<RECALL_VER|OK|BLANK>"
                return "D20CAD-ID<RECALL_VER|VERSION_NOT_FOUND>"
            if cmd=="DIFF" and len(p)==4:return self._diff(p[1],p[2],p[3])
            if cmd=="CRC_CHECK" and len(p)==2 and p[1].upper()=="ALL":
                bad=[d for d,v in self.dirs.items() if v["CRC"]!=crc(v["DATA"],5)]
                if bad:self.MONITOR_HALT=1;self.BOOT="LOCKED";return "D20CAD-ID<CRC_CHECK|FAIL|"+json.dumps(bad)
                return "D20CAD-ID<CRC_CHECK|PASS>"
            if cmd=="DEEP" and len(p)>=2:
                sub=p[1].upper();
                if sub=="SAVE":return "D20CAD-ID<DEEP|SAVE|OK|"+self.deep_snapshot()+">"
            if cmd=="STATUS":return f"D20CAD-ID<STATUS|OK|BOOT={self.BOOT}|HALT={self.MONITOR_HALT}|DEEP={len(self.goldfish_brain['deep_save_log'])}>"
            return "D20CAD-ID<ERROR|SYNTAX|UNKNOWN_COMMAND>"
        except Exception as e:
            self.goldfish_brain["last_error"]=repr(e); self._log(f"EXCEPTION|{s}|{e}"); return "D20CAD-ID<ERROR|INTERNAL>"
    def _diff(self,d,a,b):
        # Supports current + retained versions without the historical arity bug.
        va=next((h["DATA"] for h in self.dirs[d]["HISTORY"] if str(h["VER"])==a),{})
        vb=next((h["DATA"] for h in self.dirs[d]["HISTORY"] if str(h["VER"])==b),self.dirs[d]["DATA"] if str(self.dirs[d]["VER"])==b else {})
        keys=set(va)|set(vb); delta={k:[va.get(k),vb.get(k)] for k in keys if va.get(k)!=vb.get(k)}
        return "D20CAD-ID<DIFF|OK|DATA="+json.dumps(delta)+">"


class Waldorf:
    def __init__(self):
        self.overlay=WaldorfOverlay(); self.identity=Participant("waldorf-agent","AI")
        self.source_discipline="designated source files and current table state only"
    def handle(self, message): return self.overlay.ct(message)
    def rollback(self, target, reason="", expected=None, system_priority=False):
        return self.overlay.table.rollback("SYSTEM",target,reason=reason,expected_current_version_id=expected,system_priority=system_priority)


def self_test():
    w=Waldorf(); o=w.overlay
    assert "STATUS|OK" in o.ct("CT>STATUS")
    assert "READ|OK|D1" in o.ct("CT>READ|D1")
    assert "CRC_CHECK|PASS" in o.ct("CT>CRC_CHECK|ALL")
    snap=o.deep_snapshot(); assert snap
    t=o.table
    t.auth.grant(t.table_id,"TABLE_ADMIN","ROLLBACK")
    t.auth.grant(t.table_id,"TABLE_ADMIN","WRITE")
    v2=t.save_state("TABLE_ADMIN",{"scene":"A"})
    v3=t.save_state("TABLE_ADMIN",{"scene":"B"})
    r=t.rollback("TABLE_ADMIN",v2.version_id,consensus=True,expected_current_version_id=v3.version_id)
    assert r["status"]=="ROLLBACK_SUCCESS"
    assert t.current().data==v2.data
    assert r["sequestered"] in t.sequestered
    denied=t.rollback("TABLE_ADMIN",v2.version_id,consensus=False)
    assert denied["status"]=="ROLLBACK_ACCESS_DENIED"
    # Ensure identity/name administration is not present on table authorization surface.
    assert "NAME_ADMIN" not in t.auth.table_roles.get(t.table_id,{}).get("TABLE_ADMIN",set())
    return {"status":"PASS","deep_snapshot":snap,"rollback":r,"denied":denied}


def main():
    print(json.dumps(self_test(),indent=2,default=str))

if __name__=="__main__": main()
